package com.example.projectlinx;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class roomlocator extends AppCompatActivity {

    public roomlocator()  {
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roomlocator);
    }
}