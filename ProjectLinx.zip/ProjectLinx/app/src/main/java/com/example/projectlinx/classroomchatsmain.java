package com.example.projectlinx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class classroomchatsmain extends AppCompatActivity {
    ImageButton classroomchatButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classroomchatsmain);
        classroomchatButton = (ImageButton) findViewById(R.id.classroomchat);

        classroomchatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(classroomchatsmain.this, schedule.class);
                startActivity(intentLoadNewActivity);
            }
        });
    }
}