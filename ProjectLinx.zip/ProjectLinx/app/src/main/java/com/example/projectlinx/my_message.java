package com.example.projectlinx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class my_message extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_message);
    }
}